<?php

include 'config.php';

if(isset($_POST['kw']) && $_POST['kw'] != ''){
	$kws = "%{$_POST[kw]}%";
	
    $query = "SELECT player_name FROM playerinv WHERE player_name LIKE ? limit 10" ;
	$stmt = $link->prepare($query);
	$stmt->bind_param('s', $kws);
	$stmt->execute();
	
	
	$stmt->bind_result($player);	
	
	$i = 0;
	$count = 12;
	if($count > 0){
		while ($stmt->fetch()){
				$i++;
				echo '<div style="display:inline;">';
				echo '<img width="20" height="20" src="http://minotar.net/avatar/'.$player.'/50.png" alt="..."><b>Player:</b> '.$player;
				echo '</div>';
				
				if($i == 10) break; //STOP
		}
	}else{
		echo "<div id='no_result'>This player doesn't exist :(</div>";
	}
}
?>