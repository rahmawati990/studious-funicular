<head>
    <meta charset="utf-8">	
    <title>Web Inventory</title>
	<link href="./css/tooltip-classic.css" rel="stylesheet">
	<script src="./js/jquery.js"></script>
</head>
<body>
	<div style="padding:10px;text-align: center;border-bottom: 2px solid #FE2E2E;width:100%;top:0px;background-image: url('./img/bg.png')">
	<img src="./img/logo.png"></img>
		<form action="" method="post">
			<input class="playernameinput" name='player' id='player' placeholder='Type player name...' value=""><input class="button2" type="submit" value='Find!'>
		</form>
	</div>
	<center>
	<style>
		body{
			background-image: url('./img/bg.jpg');
			background-size: 100% auto;
			padding: 0px;
			margin:0;
		}
		.shadowfilter {
			-webkit-filter: drop-shadow(0px 0px 0px rgba(255,255,255,0.80));
			-webkit-transition: all 0.5s linear;
			-o-transition: all 0.5s linear;
			transition: all 0.5s linear;
		}
		.shadowfilter:hover {
			-webkit-filter: drop-shadow(0px 0px 8px rgba(0, 231, 255, 0.8));
		}
		.playernameinput{
			height: 40px;
			padding-left: 5px;
		}
		.button2{
			height: 40px;
			font-weight: bold;
			background-color: #01A9DB;
			color: white;
			width:50px;

border:none !important;

box-shadow:none !important;
		}
		.button2:hover{
			background-color: #2ECCFA;
		}
	</style>
	<div id='results' style="text-align:left;position: absolute;left: 50%;margin-left:-424px;width: 848px;" ></div></center>
	<!--- AUTO SEARCH FOR NAMES --->
	<script type="text/javascript">
		$(document).ready(function() {
		$("#player").keyup(function(){
			var kw = $("#player").val();
			if(kw != ''){    
			$.ajax({
				 type: "POST", 
				 url: "result.php",
				 data: "kw="+ kw, 
				 success: function(option){
					if (option == "LOL") {
						$("#results2").html(option);
					} else {
						$("#results").html(option);				
					}
				}
			});    
		}			  
		else{ 
			$("#results").html("");   
		} return false;   });
			$(".overlay").click(function(){
			$(".overlay").css('display','none');
			$("#results").css('display','none');
		});    
			$("#player").focus(function(){
			$(".overlay").css('display','block');
			$("#results").css('display','block');   
		 });
		 });
	</script>

<?php
include_once 'config.php';

$defaultname = "Default Name"; #Name for an item that doesnt have any custom name (All items should now have their names)

if (isset($_POST['player']) && !($_POST['player'] == NULL)){
	
	$player = $_POST['player'];
	
	$query  = "SELECT player_name,inventory,armor,hp,last_seen FROM playerinv WHERE player_name = ?";
	$stmt = $link->prepare($query);
	$stmt->bind_param('s', $player);
	$stmt->bind_result($player, $inventory, $armor, $hp, $seen);
	
	
	$stmt->execute();
	$stmt->store_result();
	$stmt->fetch();
	
	if (!isset($seen)){
		echo "<br>";
		echo "<center><b>This Player doesn't exist</b></center>";
		die;
	}
	
	//ITEM ID LIST THAT WE WANT WITHOUT ITEMDATA
	$array = array(276, 277, 308, 307, 279, 278, 293, 310, 311, 312, 313, 261, 272, 425, 419, 256, 257, 258, 267, 292, 306, 309, 417, 373, 283, 284, 285, 286, 294, 314, 315, 316, 317, 346, 418, 298, 299, 300, 275, 301, 334, 268, 269, 270, 271, 290, 302, 303, 304, 305);
	
	echo '<div style="margin: 0 auto; width: 900px;height: 515px;z-index: -2;margin-top: 30px;">';	
	echo '<br>';
	//echo '<center><div style="z-index: -1;position:absolute;left:50%;margin-left: -50%">';
	//echo '<center><div style="height:30px;background-color: gray;width: 848px;position:absolute;left:50%;margin-left:-424px;z-index: 0;margin-top: 200px;">Minecraft 1.8</div></center>';
	echo '<img src="./img/mc.png" style="z-index: 0;position:absolute;left:50%;margin-left:-424px;border: 2px solid red;transform:perspective(999px);">';
	///echo '</div>';
	echo '<center><div style="position: relative;margin-top: 70px;">';
	
	echo "<img src='skin.php?u=".$player."&s=280&v=front' style='position: absolute; top:0px;margin-left:40px;margin-top:-10px;'>";
	
	//HP MAX LOW FEED LVL
	//$hp = $row['hp'];
	$hp = explode(":", $hp);
			
	//PLAYER LOUGOUT TIME
	$time = time();
	$dif = ($time - $seen)/60;
	//$inventory = $row['inventory'];
	//$armor = $row['armor'];
			
	//ADDITIONAL PLAYER STATS
	echo '<font color=white>';
	echo '<span style="position: absolute; top:0px;margin-left:168px;align: left;">';
	echo '<div style="text-align: left;align: left;float:left;"><br><img src="http://minotar.net/avatar/'.$player.'/50.png" height="16" width="16"></img> '.$player;
	echo '<br><img src="./img/level.png" height="16" width="16"></img> '.$hp[3];
	echo '<br><img src="./img/heart.png" height="16" width="16"></img> '.$hp[0].'/'.$hp[1];
	echo '<br><img src="./img/online.png" height="16" width="16"></img> '.round($dif, 0).' min. ago';
	echo '</div>';
	echo '</span></font></font>';
	echo'<img src="./img/gui.png" style="z-index: 20;" ></img><br><br>';

		if (!($armor == NULL)){
			//ARMOR
			$armor= ltrim($armor, '[');
			$armor= rtrim($armor, ']');		
			$brneni = explode(";,", $armor);
			for( $i= 0 ; $i <= 3 ; $i++ ){
				$top = (36 * $i) + 1;
				
				$curarmor = $brneni[$i];
				if (!($curarmor == 'none' || $curarmor == ' none' || $curarmor == ' none;')) {
					//CONVERTING MINECRAFT COLOURS TO NORMAL ONES
					$curarmor = str_replace("§l","<b>", $curarmor);
					$curarmor = str_replace("§1","<font color='#0000AA'>", $curarmor);
					$curarmor = str_replace("§2","<font color='#00AA00'>", $curarmor);
					$curarmor = str_replace("§3","<font color='#00AAAA'>", $curarmor);
					$curarmor = str_replace("§4","<font color='#AA0000'>", $curarmor);
					$curarmor = str_replace("§5","<font color='#AA00AA'>", $curarmor);
					$curarmor = str_replace("§6","<font color='#FFAA00'>", $curarmor);
					$curarmor = str_replace("§7","<font color='#AAAAAA'>", $curarmor);
					$curarmor = str_replace("§8","<font color='#555555'>", $curarmor);
					$curarmor = str_replace("§9","<font color='#5555FF'>", $curarmor);
					$curarmor = str_replace("§a","<font color='#55FF55'>", $curarmor);
					$curarmor = str_replace("§b","<font color='#55FFFF'>", $curarmor);
					$curarmor = str_replace("§c","<font color='#FF5555'>", $curarmor);
					$curarmor = str_replace("§d","<font color='#FF55FF'>", $curarmor);
					$curarmor = str_replace("§e","<font color='#FFFF55'>", $curarmor);
					$curarmor = str_replace("§F","<font color='#FFFFFF'>", $curarmor);
					$curarmor = str_replace("§f","<font color='#FFFFFF'>", $curarmor);
					$curarmor = str_replace("§r","<font color='#FFFFFF'>", $curarmor);
					$curarmor = str_replace("§0","<font color='#000000'>", $curarmor);
					$curarmor = str_replace("§k","<font color='#000000'>", $curarmor);
					//GETTING DIFFERENT PARTS OF ITEM
					$curarmor = explode("@", $curarmor);
					echo '<div class="accmarket accmarket-effect-4" style="position: absolute;float:left;margin-left: -172px;top: '.$top.'px;z-index: 1000;">';
					echo '<span class="accmarket-item">';
					
						//ITEM ID
						$curarmor[0] = str_replace(" ","", $curarmor[0]);
						$id = explode("-", $curarmor[0]);
						
						if (in_array($id[0], $array)) {
							echo '<img class="shadowfilter" height="36" width="36" src="./blocks2/'.$id[0].'-0.png">';
						} else{
							echo '<img class="shadowfilter" height="24" width="24" src="./blocks2/'.$curarmor[0].'.png">';
						}
						//ITEM STACK SIZE
						if (!($curarmor[3] == 1)){
							echo '<div style="position: absolute;margin-top:-12px;"><font color=white>'.$curarmor[3].'</font></div>';
						}
							
						echo '<span class="accmarket-content clearfix">';
						echo '<span class="accmarket-text">';
						//NAME CHECK
						if (!($curarmor[1] == "none")){
							echo '<b>'.$curarmor[1].'</b>';
						} else {
							echo '<font color=white><b>'.$defaultname.'</b></font>';					
						}
						//ECHANT CHECK
						if (!($curarmor[4] == "null")){
							$curarmor[4] = str_replace("]","", $curarmor[4]);
							$curarmor[4] = str_replace("[","", $curarmor[4]);
							$curarmor[4] = str_replace("{","", $curarmor[4]);
							$curarmor[4] = str_replace("}","", $curarmor[4]);
							$ench = explode(",", $curarmor[4]);
							echo '<font color=white>';
							for($t=1;$t <= 36;$t+=2){
								if (!($ench[$t] == NULL)){
								$enchant = explode("=", $ench[$t]);
								$enchant[1] = str_replace(";","", $enchant[1]);
								$enchant[0] = str_replace("_"," ", $enchant[0]);
								echo '<br>'.$enchant[0].': '.$enchant[1];
								}							
							}
							echo '</font>';
						}
						echo '<br>';
						//LORE CHECK
						if (!($curarmor[2] == "null")){
							$curarmor[2]= ltrim($curarmor[2], '[');
							$curarmor[2]= rtrim($curarmor[2], ']');
							$lore = explode(",", $curarmor[2]);
							for( $a= 0 ; $a <= 15 ; $a++ ){
								if (!($lore[$a] == NULL)){
									echo '<br>'.$lore[$a];
								}
							}
						}
						echo '</font></div>';
						echo '</span>';
						echo '</span>';
						echo '</span>';					
				}
			}
		}
			//INVENTORY
			//REMOVING UNNECESSARLY THINGS
			$inventory= ltrim($inventory, '[');
			$inventory= rtrim($inventory, ']');
			$inv = explode(";,", $inventory);
			for( $i= 0 ; $i <= 36 ; $i++ ){
				if (!($inv[$i] == NULL)){
					if ($i <= 8){
						$px2 = 36 * $i;
						$px = -167 + $px2;
						echo '<div class="accmarket accmarket-effect-4" style="position: absolute;float:left;margin-left: '.$px.'px;top: 160px;z-index: 1000;">';
						echo '<span class="accmarket-item">';
					} else if (9 <= $i && $i < 18){
						$px2 = 36 * ($i - 9);
						$px = -167 + $px2;
						echo '<div class="accmarket accmarket-effect-4" style="position: absolute;float:left;margin-left: '.$px.'px;top: 196px;z-index: 1000;">';
						echo '<span class="accmarket-item">';				
						
					} else if (18 <= $i && $i < 27){
						$px2 = 36 * ($i - 18);
						$px = -167 + $px2;
						echo '<div class="accmarket accmarket-effect-4" style="position: absolute;float:left;margin-left: '.$px.'px;top: 232px;z-index: 1000;">';
						echo '<span class="accmarket-item">';						
					} else if (27 <= $i && $i < 36){
						$px2 = 36 * ($i - 27);
						$px = -167 + $px2;
						echo '<div class="accmarket accmarket-effect-4" style="position: absolute;float:left;margin-left: '.$px.'px;top: 275px;z-index: 1000;">';
						echo '<span class="accmarket-item">';						
					}
					
					//CONVERTING MINECRAFT COLOURS TO NORMAL ONES
					$curitem = $inv[$i];
					$curitem = str_replace("§l","<b>", $curitem);
					$curitem = str_replace("§1","<font color='#0000AA'>", $curitem);
					$curitem = str_replace("§2","<font color='#00AA00'>", $curitem);
					$curitem = str_replace("§3","<font color='#00AAAA'>", $curitem);
					$curitem = str_replace("§4","<font color='#AA0000'>", $curitem);
					$curitem = str_replace("§5","<font color='#AA00AA'>", $curitem);
					$curitem = str_replace("§6","<font color='#FFAA00'>", $curitem);
					$curitem = str_replace("§7","<font color='#AAAAAA'>", $curitem);
					$curitem = str_replace("§8","<font color='#555555'>", $curitem);
					$curitem = str_replace("§9","<font color='#5555FF'>", $curitem);
					$curitem = str_replace("§a","<font color='#55FF55'>", $curitem);
					$curitem = str_replace("§b","<font color='#55FFFF'>", $curitem);
					$curitem = str_replace("§c","<font color='#FF5555'>", $curitem);
					$curitem = str_replace("§d","<font color='#FF55FF'>", $curitem);
					$curitem = str_replace("§e","<font color='#FFFF55'>", $curitem);
					$curitem = str_replace("§F","<font color='#FFFFFF'>", $curitem);
					$curitem = str_replace("§f","<font color='#FFFFFF'>", $curitem);
					$curitem = str_replace("§r","<font color='#FFFFFF'>", $curitem);
					$curitem = str_replace("§0","<font color='#000000'>", $curitem);
					$curitem = str_replace("§k","<font color='#000000'>", $curitem);
					
					
					//GETTING DIFFERENT PARTS OF ITEM
					$curitem = explode("@", $curitem);
					//ITEM ID
					$curitem[0] = str_replace(" ","", $curitem[0]);
					$id = explode("-", $curitem[0]);
					
					if (in_array($id[0], $array)) {
						echo '<img class="shadowfilter" height="24" width="24" src="./blocks2/'.$id[0].'-0.png">';
					} else{
						echo '<img class="shadowfilter" height="24" width="24" src="./blocks2/'.$curitem[0].'.png">';
					}
					//ITEM STACK SIZE
					if (!($curitem[3] == 1)){
						echo '<div style="position: absolute;margin-top:-12px;"><font color=white>'.$curitem[3].'</font></div>';
					}
						
					echo '<span class="accmarket-content clearfix">';
					echo '<span class="accmarket-text">';
					//NAME CHECK
					if (!($curitem[1] == "none")){
						echo '<b>'.$curitem[1].'</b>';
					} else {
						echo '<font color=white><b>'.$defaultname.'</b></font>';					
					}
					//ECHANT CHECK
					if (!($curitem[4] == "null")){
						$curitem[4] = str_replace("]","", $curitem[4]);
						$curitem[4] = str_replace("[","", $curitem[4]);
						$curitem[4] = str_replace("{","", $curitem[4]);
						$curitem[4] = str_replace("}","", $curitem[4]);
						$ench = explode(",", $curitem[4]);
						echo '<font color=white>';
						for($t=1;$t <= 36;$t+=2){
							if (!($ench[$t] == NULL)){
							$enchant = explode("=", $ench[$t]);
							$enchant[1] = str_replace(";","", $enchant[1]);
							$enchant[0] = str_replace("_"," ", $enchant[0]);
							echo '<br>'.$enchant[0].': '.$enchant[1];
							}							
						}
						echo '</font>';
					}
					echo '<br>';
					//LORE CHECK
					if (!($curitem[2] == "null")){
						$curitem[2]= ltrim($curitem[2], '[');
						$curitem[2]= rtrim($curitem[2], ']');
						$lore = explode(",", $curitem[2]);
						for( $a= 0 ; $a <= 15 ; $a++ ){
							if (!($lore[$a] == NULL)){
								echo '<br>'.$lore[$a];
							}
						}
					}
					echo '</font></div>';
					echo '</span>';
					echo '</span>';
					echo '</span>';
				}
			}
			
			
			echo '</div>';
			echo '</div>';
		}
?>
</body>