<?php
$db_host= "localhost";  
$db_user= "root";  
$db_password= "123456"; 
$db_name= "mcdatabase"; 
$link = new mysqli("$db_host","$db_user","$db_password","$db_name") or die("Error: ".mysqli_error($link));

$link->set_charset("utf8");
?>